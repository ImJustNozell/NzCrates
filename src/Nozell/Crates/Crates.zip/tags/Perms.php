<?php

namespace Nozell\Crates\tags;

final class Perms
{
    public const Admin = "nzcrates.admin";
    public const Default = "nzcrates.default";
}
