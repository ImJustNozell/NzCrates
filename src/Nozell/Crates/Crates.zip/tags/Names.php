<?php

namespace Nozell\Crates\tags;

final class Names
{
    public const Ender = "ender";
    public const Magma = "magma";
    public const Ice = "ice";
    public const Pegasus = "pegasus";
    public const Mage = "mage";
}
